//package com.MythiCode.ocrkit.Model;
//
//public class FrameModel {
//    public float x;
//    public float y;
//    public float minX;
//    public float minY;
//    public float midX;
//    public float midY;
//    public float maxX;
//    public float maxY;
//    public float width;
//    public float height;
//}
