package com.MythiCode.ocrkit.Model;

public class CornerPointModel {
    public CornerPointModel(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public float x;
    public float y;
}
